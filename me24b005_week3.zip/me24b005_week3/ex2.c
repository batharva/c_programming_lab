#include <stdio.h>
#include <limits.h>
int main(){
    int arr[5] ;
    printf("Entre 5 numbers:");
    for(int i=0;i<5;i++){
    	scanf("%d",&arr[i]);
    }
    int minNo=INT_MAX,
	maxNo=INT_MIN;
    for(int i=0;i<5;i++){
    	if(arr[i]>maxNo){
		maxNo=arr[i];
	}
	if(arr[i]<minNo){
		minNo=arr[i];
	}
    }
    printf("Maximum number:%d\nMinimum number:%d",maxNo,minNo);
    return 0;
}

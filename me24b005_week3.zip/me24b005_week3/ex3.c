#include <stdio.h>
int main(){
    int n,sum=0;
    printf("Entre a number:");
    scanf("%d",&n);
    for (int i = 1; i <=n; i++)
    {
        if (i%2==0)
        {
            sum+=i;
        }
        
    }
    printf("Sum of all even numbers till %d is %d",n,sum);
    return 0;
}
#include <stdio.h>
void right_half_pyramid(int n){
    for ( int i = 0; i < n+1; i++)
    {
        for (int j = 0; j < i; j++)
        {
            printf("* ");
        }
        printf("\n");
    }
}
void left_half_pyramid(int n){
    for (int i = 0; i < n+1; i++)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            printf("* ");
        }
        printf("\n");
    }
    
}

void full_pyramid(int n){
    for (int i = 0; i < n+1; i++)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            printf("* ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("* ");
        }
        printf("\n");
        
    }
    
}
void inverted_full_pyramid(int n){
    for (int i = n; i >0; i--)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            printf("* ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("* ");
        }
        printf("\n");
        
    }
    
}
void inverted_right_half_pyramid(int n){
    for ( int i = n; i > 0; i--)
    {
        for (int j = 0; j < i; j++)
        {
            printf("* ");
        }
        printf("\n");
    }

}

void inverted_left_half_pyramid(int n){
    for (int i = n; i > 0; i--)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            printf("* ");
        }
        printf("\n");
    }

}
void rhombus(int n){
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < n; j++)
        {
            printf("* ");
        }
        printf("\n");
    }
    
}
void diamond(int n){
    full_pyramid(n);
    for (int i = n-1; i >0; i--)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            printf("* ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("* ");
        }
        printf("\n");
        
    }
}
void hollow_square(int n){
    for (int i = 1; i <=n; i++)
    {
        if (i==1 || i==n)
        {
            for (int j = 0; j < n; j++)
            {
                printf("* ");
            } 
        }else
        {
            printf("* ");
            for (int j = 0; j < n-2; j++)
            {
                printf("  ");
            }
            printf("* ");
        }
        printf("\n");
        
    }
    
}
void hollow_full_pyramid(int n){
    for (int i = 0; i < n+1; i++)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            if (j==0 || i==n)
            {
                printf("* ");
            }else{
                printf("  ");
            }
        }
        for (int j = 0; j < i-1; j++)
        {
            if (j==i-2 || i==n)
            {
                printf("* ");
            }else 
            {
                printf("  ");
            }
            
            
        }
        printf("\n");
        
    }
}
void inverted_hollow_full_pyramid(int n){
    for (int i = n; i >0 ; i--)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            if (j==0 || i==n)
            {
                printf("* ");
            }else{
                printf("  ");
            }
        }
        for (int j = 0; j < i-1; j++)
        {
            if (j==i-2 || i==n)
            {
                printf("* ");
            }else 
            {
                printf("  ");
            }
            
            
        }
        printf("\n");
        
    }
}
void hollow_diamond(int n){
    for (int i = 0; i < n+1; i++)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            if (j==0)
            {
                printf("* ");
            }else{
                printf("  ");
            }
        }
        for (int j = 0; j < i-1; j++)
        {
            if (j==i-2)
            {
                printf("* ");
            }else 
            {
                printf("  ");
            }
            
            
        }
        printf("\n");
        
    }
    for (int i = n-1; i >0 ; i--)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            if (j==0)
            {
                printf("* ");
            }else{
                printf("  ");
            }
        }
        for (int j = 0; j < i-1; j++)
        {
            if (j==i-2)
            {
                printf("* ");
            }else 
            {
                printf("  ");
            }
            
            
        }
        printf("\n");
        
    }
}
void number_triangle(int n){
    int a=1;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < i; j++)
        {
            printf("%d ",a);
            a++;
        }
        printf("\n");
    }
    
}
//Pascals Triangle
int factorial(int n){
    int factorial=1; 
    for (int i = 1; i <=n; i++)
    {
        factorial*=i;
    }
    return factorial;
}
int ncr(int n,int r){
    return factorial(n)/(factorial(r)*factorial(n-r));
}
void pascals_triangle(int n){
    for (int i = 0; i < n+1; i++)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        if (i==0)
        {
            printf("%d  ",1);
        }
        for (int j = 0; j < i; j++)
        {
            printf("%d  ",ncr(i-1,j));
        }
        printf("\n");
    }
    
}

void hourglass(int n){
    inverted_full_pyramid(n);
    for (int i = 2; i <=n; i++)
    {
        for (int j = 0; j < n-i; j++)
        {
            printf("  ");
        }
        for (int j = 0; j < i; j++)
        {
            printf("* ");
        }
        for (int j = 1; j < i; j++)
        {
            printf("* ");
        }
        
        printf("\n");
    }
    
    
}
int main()
{
    printf("\nEntre number of rows to print:");
    int rows;
    scanf("%d",&rows);  
    
    printf("1.Right Half Pyramid.");
    right_half_pyramid(rows);
    
    printf("2.Left Half Pyramid.");
    left_half_pyramid(rows);

    printf("3.Full Pyramid.");
    full_pyramid(rows);
    
    printf("4.Inverted Right Half Pyramid.\n");
    inverted_right_half_pyramid(rows);

    printf("5.Inverted Left Half Pyramid.\n");
    inverted_left_half_pyramid(rows);

    printf("6.Inverted Full Pyramid.\n");
    inverted_full_pyramid(rows);

    printf("7.Rhombus.\n");
    rhombus(rows);

    printf("8.Diamond.");
    diamond(rows);

    printf("9.Hourglass.\n");
    hourglass(rows);

    printf("10.Hollow Square.\n");
    hollow_square(rows);

    printf("11.Hollow Full Pyramid.");
    hollow_full_pyramid(rows);

    printf("12.Inverted Hollow Full Pyramid.\n");
    inverted_hollow_full_pyramid(rows);

    printf("13.Hollow Diamond.");
    hollow_diamond(rows);

    printf("14.Number Triangle.");
    number_triangle(rows);

    printf("15.Pascals Triangle.");
    pascals_triangle(rows);
    return 0;
}
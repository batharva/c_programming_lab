#include <stdio.h>
int main(){
    int hr,sec,min;
    printf("Entre Hrs, Mins and Secs:");
    scanf("%d %d %d",&hr,&min,&sec);
    printf("Total time in seconds %d \n",(hr*3600+min*60+sec));
    return 0;
}
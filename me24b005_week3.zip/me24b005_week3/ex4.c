#include <stdio.h>
int main(){
    int num;
    printf("Entre a number to be reversed:");
    scanf("%d",&num);
    int reverse_num=0,sum=0;
    while (num>0)
    {
        sum+=num%10;
        reverse_num=reverse_num*10+num%10;
        num=num/10; 
    }
    printf("Sum of digits is %d\n",sum);
    printf("Reversed number is %d",reverse_num);
    return 0;
}
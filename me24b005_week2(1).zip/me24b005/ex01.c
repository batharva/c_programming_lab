#include <stdio.h>
int main(){
	printf("Name: Atharva Bhosale\nAge: 18 years old");
	return 0;
}

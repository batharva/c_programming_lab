#include <stdio.h>
int main(){

	printf("%10d %-10d\n",1,1);
	printf("%10d %-10d\n",22,22);
	printf("%10d %-10d\n",333,333);
	printf("%10d %-10d\n",4444,4444);
	printf("%10d %-10d\n",55555,55555);
	return 0;
}

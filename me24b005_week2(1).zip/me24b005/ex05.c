#include <stdio.h>
int main(){
	int num1,num2,num3;
	float num4;
	scanf("%d %d %d %f",&num1,&num2,&num3,&num4);
	int avg=(num1+num2+num3)/3;
	float sum = num1+num2+num3+num4;
	printf("Average of integers:%d \nSum of all values:%f",avg,sum);

	return 0;
}

#include <stdio.h>
int main(){
	float num=123.456789;
	printf("%15.2f \n",num);
	printf("%15.3e \n",num);
	printf("%.3f \n",num);
	printf("%015.1f \n",num);

	return 0;
}

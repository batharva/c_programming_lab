#include <stdio.h>
int main(){

	printf("%010d %-10d\n",1,1);
	printf("%010d %-10d\n",22,22);
	printf("%010d %-10d\n",333,333);
	printf("%010d %-10d\n",4444,4444);
	printf("%010d %-10d\n",55555,55555);
	return 0;
}

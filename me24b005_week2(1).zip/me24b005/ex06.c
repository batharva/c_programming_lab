#include <stdio.h>
int main(){

        printf("%10s %10s %10s \n","Number","Square","Cube");
        for(int i=1;i<=10;i++){
                printf("%10d %10d %10d \n",i,i*i,i*i*i);
        }
        return 0;
}


#include <stdio.h>
int reversenum(int num) //function to reverse the number
{
    int reverse=0;
    while (num>0)
    {
        reverse = num%10 +reverse*10;
        num=num/10;
    }
    return reverse;
}
int palindrome(int num){ //function to check palindrome
    int reverse=reversenum(num);
    if (reverse==num)
    {
        return 1;
    }else{
        return 0;
    }
    
}
int main(){
    //input array
    int n;
    printf("Entre the number of elements:");
    scanf("%d",&n);
    printf("Entre %d numbers:",n);
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
    }
    //print output
    for (int i = 0; i < n; i++)
    {
        if (palindrome(arr[i]))
        {
            printf("%d is a palindrome.\n",arr[i]);
        }else{
            printf("%d is not a palindrome.\n",arr[i]);
        }
        
    }
    
    return 0;
}
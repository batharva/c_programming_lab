#include <stdio.h>
int reversenum(int num) //function to reverse the number
{
    int reverse=0;
    while (num>0)
    {
        reverse = num%10 +reverse*10;
        num=num/10;
    }
    return reverse;
}
int main(){
    //array input
    int n;
    printf("Entre the number of elements:");
    scanf("%d",&n);
    printf("Entre %d numbers:",n);
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
    }
    //print the reverse number and its sum
    int sum=0;
    for (int i = 0; i < n; i++)
    {
        arr[i]=reversenum(arr[i]);
        printf("Reversed number:%d\n",arr[i]);
        sum+=arr[i];
    }
    printf("Sum of reversed numbers:%d",sum);
    return 0;
}
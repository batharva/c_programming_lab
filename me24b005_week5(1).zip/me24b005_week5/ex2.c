#include <stdio.h>
int main(){
    //intput array
    int n;
    printf("Entre the number of elements:");
    scanf("%d",&n);
    printf("Entre the sorted array elemtns:");
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
    }
    //input key to search
    int key;
    printf("Entre the key value:");
    scanf("%d",&key);
    //searching for two numbers whose sum is equal to key
    int first,second;
    int flag=0;

    for (int i = 0; i < n-1; i++)
    {
        for (int j = i+1; j < n; j++)
        {
            if ((arr[i]+arr[j])==key)
            {
                second=arr[j];
                first=arr[i];
                flag=1;
            }
            
        }
        if (flag)
        {
            break;
        }
        
    }
    printf("Pair found: %d + %d = %d",first,second,key);
    return 0;
}
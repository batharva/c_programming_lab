#include <stdio.h>
int main(){
    int n;
    printf("Entre the number of elements:");
    scanf("%d",&n);
    printf("Entre %d numbers:",n);
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
    }
    int  difference=0;
    int first,second;
    for (int i = 0; i < n-1; i++)
    {
        
        for (int j = i+1; j < n; j++)
        {
            if ((arr[j]-arr[i])>difference)
            {
                first=arr[i];
                second =arr[j];
                difference=second-first;
            }
            
        }
        
    }
    printf("Maximum difference between %d and %d, where larger appears after smaller is %d\n",first,second,difference);
    return 0;
}
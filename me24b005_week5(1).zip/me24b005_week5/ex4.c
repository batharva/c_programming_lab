#include <stdio.h>
int main(){
    //input array
    int n;
    printf("Entre the number of elements:");
    scanf("%d",&n);
    printf("Entre %d numbers:",n);
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
    }
    //print binary form of a number
    for (int i = 0; i < n; i++)
    {
        int temp=arr[i];
        printf("Binary of %d is ",arr[i]);
        while (temp>0)
        {
            printf("%d",temp%2);
            temp=temp/2;
        }
        printf("\n");
    }
    
    
    return 0;
}
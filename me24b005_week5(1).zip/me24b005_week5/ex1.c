#include <stdio.h>
#include <math.h>
int primecheck(int num) //check the give number is prime or not
{
    int flag=1;
    if (num==0 || num==1)
    {
        return 0;
    }else{
        for (int i = 2; i <sqrt(num); i++)
        {
            if (num%i==0)
            {
                return 0;
                flag=0;
            }
        }
        if (flag)
        {
            return 1;
        }
        
    }
    
}
int main(){
    //input of array
    int n;
    printf("Entre the number of elements:");
    scanf("%d",&n);
    printf("Entre %d numbers:",n);
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
    }
    //print prime numbers in array
    printf("Prime numbers are:\n");
    for (int i = 0; i < n; i++)
    {
        if (primecheck(arr[i]))
        {
            printf("%d ",arr[i]);
        }
        
    }
    
    
    return 0;
}
#include <stdio.h>
int main(){
    int n1;
    printf("Entre number of elements in first arrya:");
    scanf("%d",&n1);
    int arr1[n1];
    printf("Entre %d numbers:",n1);
    for (int i = 0; i < n1; i++)
    {
        scanf("%d",&arr1[i]);
    }
    int n2;
    printf("Entre number of elements in second arrya:");
    scanf("%d",&n2);
    int arr2[n2];
    printf("Entre %d numbers:",n2);
    for (int i = 0; i < n2; i++)
    {
        scanf("%d",&arr2[i]);
    }
    arr1[n1+n2];
    for (int i = 0; i < n2; i++)
    {
        arr1[n1+i]=arr2[i];
    }
    
    for (int i = 0; i < n1+n2; i++)
    {
        for (int j = 0; j < i; j++)
        {
            if (arr1[i]<arr1[j])
            {
                int temp=arr1[j];
                arr1[j]=arr1[i];
                arr1[i]=temp;
            }
        }
    }
    printf("Mergerd and sorted array:");
    for (int i = 0; i < n1+n2; i++)
    {
        printf("%d ",arr1[i]);
    }
    

    return 0;

}
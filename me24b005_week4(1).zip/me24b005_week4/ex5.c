#include <stdio.h>
int main(){
    int n;
    printf("Entre number of elements:");
    scanf("%d",&n);
    int arr[n];
    printf("Entre %d numbers:",n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
    }
    int key;
    printf("Entre the number to search:");
    scanf("%d",&key);
    for (int i = 0; i < n; i++)
    {
        if (arr[i]==key)
        {
            printf("Number found at position %d",i+1);
            break;
        }
        
    }
    
    return 0;

}
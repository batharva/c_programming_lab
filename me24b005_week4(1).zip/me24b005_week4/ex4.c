#include <stdio.h>
int main(){
    int n;
    printf("Entre number of elements:");
    scanf("%d",&n);
    int arr[n];
    printf("Entre %d numbers:",n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < i; j++)
        {
            if (arr[i]<arr[j])
            {
                int temp=arr[j];
                arr[j]=arr[i];
                arr[i]=temp;
            }
        }
    }
    int a=1,
    unique=arr[0],
    unique_ele[a];
    unique_ele[0]=arr[0];
    for (int i = 0; i < n; i++)
    {
        if (unique==arr[i])
        {
            continue;
        }else{
            unique=arr[i];
            a++;
            unique_ele[a-1]=arr[i];
        }
    }
    
    int frequency[a];
    for (int i = 0; i < a; i++)
    {
        frequency[i]=0;
    }
    
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (unique_ele[i]==arr[j])
            {
                frequency[i]++;
            }
            
        }
        
    }
    
    
    
    printf("Frequency of all elements:\n");
    for (int i = 0; i < a; i++)
    {
        printf("%d occurs %d time(s)\n",unique_ele[i],frequency[i]);
    }
    
    return 0;

}
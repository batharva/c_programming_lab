#include <stdio.h>
#include <limits.h>
int main(){
    int n;
    printf("Entre number of elements:");
    scanf("%d",&n);
    int arr[n];
    printf("Entre %d numbers:",n);
    int sum=0;
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
        sum+=arr[i];
    }
    int minNo=INT_MAX;
    int maxNo=INT_MIN;
    for (int i = 0; i<n; i++)
    {
        if (minNo>arr[i])
        {
            minNo=arr[i];
        }
        if (maxNo<arr[i])
        {
            maxNo=arr[i];
        }
        
    }
    float mean=sum/n;
    printf("Sum=%d\nMean=%d\nMin element=%d\nMax element=%d",sum,mean,minNo,maxNo);
    return 0;

}
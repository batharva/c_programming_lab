#include <stdio.h>
int main(){
    int n;
    printf("Entre number of elements:");
    scanf("%d",&n);
    int arr[n];
    printf("Entre %d numbers:",n);
    int even=0,odd=0;
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("Reversed array:\n");
    for (int i = n-1; i >=0; i--)
    {
        printf("%d ",arr[i]);
    }
    
    return 0;

}
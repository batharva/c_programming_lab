#include <stdio.h>
int main(){
    int n;
    printf("Entre number of elements:");
    scanf("%d",&n);
    int arr[n];
    printf("Entre %d numbers:",n);
    int even=0,odd=0;
    for (int i = 0; i < n; i++)
    {
        scanf("%d",&arr[i]);
        if (arr[i]%2==0)
        {
            even++;
        }else{
            odd++;
        }
    }
    printf("Even numbers count:%d\nOdd numbers count:%d",even,odd);
    return 0;

}
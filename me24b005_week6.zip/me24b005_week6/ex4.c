#include <stdio.h>
#include <time.h>
#include <stdlib.h>
void selection(int arr[],int n){
    for (int i = 0; i < n-1; i++)
    {
        for (int j = i+1; j < n; j++)
        {
            if (arr[i]>arr[j])
            {
                int temp=arr[j];
                arr[j]=arr[i];
                arr[i]=temp;
            }
            
        }
        
    }
    
}
int main(){
    srand(time(NULL));
    int n=rand()%10;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        arr[i]=rand()%100;
    }
    printf("Randomly generated array is:\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d ",arr[i]);
    }
    
    selection(arr,n);
    printf("\nThe seocnd smallest element in the array is:\n%d\n",arr[1]);

    
    return 0;
}
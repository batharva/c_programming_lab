#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int median(int arr[],int n){
    if (n%2==0)
    {
        return (arr[n/2-1]+arr[n/2+1]);
    }else{
        return arr[n/2];
    }
    
}
int mean(int arr[],int n){
    int sum=0;
    for (int i = 0; i < n; i++)
    {
        sum+=arr[i];
    }
    return sum/n;
}
void selection(int arr[],int n){
    for (int i = 0; i < n-1; i++)
    {
        for (int j = i+1; j < n; j++)
        {
            if (arr[i]>arr[j])
            {
                int temp=arr[j];
                arr[j]=arr[i];
                arr[i]=temp;
            }
            
        }
        
    }
    
}
int main(){
    srand(time(NULL));
    int n=rand()%10+1,arr[n];
    for (int i = 0; i < n; i++)
    {
        arr[i]=rand()%100;
    }
    printf("Randomly generated array is:\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d ",arr[i]);
    }
    selection(arr,n);
    int mode = 3*median(arr,n)-2*mean(arr,n);
    printf("\nMedian of randomly generated array is:\n%d\nMode of randomly generated array is:\n%d",median(arr,n),mode);
    return 0;
}


//2mean + mode = 3median
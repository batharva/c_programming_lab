#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int medial(int n,int arr[]){
    if (n%2==0)
    {
        return (arr[n/2-1]+arr[n/2+1])/2;
        
    }else{
        return arr[n/2];
    }
    
}
void selection(int arr[],int n){
    for (int i = 0; i < n-1; i++)
    {
        for (int j = i+1; j < n; j++)
        {
            if (arr[i]>arr[j])
            {
                int temp=arr[j];
                arr[j]=arr[i];
                arr[i]=temp;
            }
            
        }
        
    }
    
}
int main(){
    srand(time(NULL));
    int n=rand()%10+1;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        arr[i]=rand()%100;
    }
    printf("Randemoly generated array of size %d is:\n",n);
    for (int i = 0; i < n; i++)
    {
        printf("%d ",arr[i]);
    }
    
    selection(arr,n);

    printf("\nRandemoly generated sorted array of size %d is:\n",n);
    for (int i = 0; i < n; i++)
    {
        printf("%d ",arr[i]);
    }
    
    printf("\nThe median of sorted array is:\n%d\n", medial(n,arr));

    
    return 0;
}